"""
Management command to load products from products_data.csv into the database.

Usage:
    python manage.py load_products --csv path/to/products_data.csv
"""
import csv
from django.core.management.base import BaseCommand
from products.models import Product


class Command(BaseCommand):
    help = 'Load products from a CSV file into the database'

    def add_arguments(self, parser):
        parser.add_argument(
            '--csv',
            type=str,
            default='products_data.csv',
            help='Path to the CSV file (default: products_data.csv)',
        )
        parser.add_argument(
            '--clear',
            action='store_true',
            help='Clear existing products before loading',
        )

    def handle(self, *args, **options):
        csv_path = options['csv']

        if options['clear']:
            count = Product.objects.count()
            Product.objects.all().delete()
            self.stdout.write(self.style.WARNING(f'Cleared {count} existing products.'))

        created = 0
        skipped = 0

        try:
            with open(csv_path, newline='', encoding='utf-8') as f:
                reader = csv.DictReader(f)
                products_to_create = []

                for row in reader:
                    raw_tags = row.get('tags', '')
                    tags = [t.strip() for t in raw_tags.split(',') if t.strip()]

                    products_to_create.append(Product(
                        id=int(row['id']),
                        product_name=row['product_name'].strip(),
                        product_description=row['product_description'].strip(),
                        category=row['category'].strip(),
                        tags=tags,
                    ))

                # Bulk create, skip conflicts
                Product.objects.bulk_create(products_to_create, ignore_conflicts=True)
                created = len(products_to_create)

        except FileNotFoundError:
            self.stderr.write(self.style.ERROR(f'File not found: {csv_path}'))
            return
        except Exception as e:
            self.stderr.write(self.style.ERROR(f'Error: {e}'))
            return

        self.stdout.write(self.style.SUCCESS(
            f'Done. Loaded {created} products (skipped {skipped} duplicates).'
        ))
        self.stdout.write(f'Total products in DB: {Product.objects.count()}')
