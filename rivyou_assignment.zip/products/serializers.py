from rest_framework import serializers
from .models import Product


class ProductSerializer(serializers.ModelSerializer):
    class Meta:
        model = Product
        fields = ('id', 'product_name', 'product_description', 'category', 'tags')


class ProductCreateSerializer(serializers.ModelSerializer):
    tags = serializers.ListField(child=serializers.CharField(), required=False, default=list)

    class Meta:
        model = Product
        fields = ('product_name', 'product_description', 'category', 'tags')

    def validate_category(self, value):
        allowed = {'Smartphones', 'Chargers', 'Back Covers'}
        if value not in allowed:
            raise serializers.ValidationError(f"Category must be one of: {', '.join(allowed)}")
        return value


class SearchResultSerializer(serializers.ModelSerializer):
    relevance_score = serializers.FloatField()
    rank_reason = serializers.CharField()

    class Meta:
        model = Product
        fields = ('id', 'product_name', 'product_description', 'category', 'tags', 'relevance_score', 'rank_reason')
