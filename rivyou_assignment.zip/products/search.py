"""
Relevance ranking engine for Rivyou product search.

Three-tier system:
  Tier 1 (0.7–1.0): category matches query
  Tier 2 (0.4–0.69): tags contain query (but category doesn't match)
  Tier 3 (0.1–0.39): product_name or description contains query
"""
from .models import Product


def _normalize(text: str) -> str:
    return text.lower().strip()


def _category_matches(category: str, query: str) -> bool:
    """
    Check if the query refers to this category.
    e.g. "smartphone" / "smartphones" → "Smartphones"
         "charger" / "chargers"       → "Chargers"
         "back cover" / "cover"       → "Back Covers"
    """
    q = _normalize(query)
    cat = _normalize(category)
    # Direct substring check (handles plural/partial: "smartphone" in "smartphones")
    if q in cat or cat in q:
        return True
    # Alias map for common shorthands
    aliases = {
        'smartphone': 'smartphones',
        'phone': 'smartphones',
        'charger': 'chargers',
        'cover': 'back covers',
        'back cover': 'back covers',
        'case': 'back covers',
    }
    mapped = aliases.get(q)
    return mapped is not None and (mapped in cat or cat in mapped)


def _tag_score(tags: list, query: str) -> float:
    """
    Returns a score 0-1 for how well tags match the query.
    Exact tag match → 1.0, partial → proportional.
    """
    if not tags:
        return 0.0
    q = _normalize(query)
    exact = sum(1 for t in tags if _normalize(t) == q)
    partial = sum(1 for t in tags if q in _normalize(t) or _normalize(t) in q)
    # Exact matches are worth more
    raw = exact * 1.0 + (partial - exact) * 0.5
    return min(raw / len(tags), 1.0)


def _text_score(product_name: str, description: str, query: str) -> float:
    """Simple keyword presence score for name/description."""
    q = _normalize(query)
    score = 0.0
    if q in _normalize(product_name):
        score += 0.6
    if q in _normalize(description):
        score += 0.4
    return min(score, 1.0)


def rank_products(query: str, queryset=None) -> list:
    """
    Return a list of (product, relevance_score, rank_reason) tuples,
    sorted by descending relevance.
    """
    if queryset is None:
        queryset = Product.objects.all()

    q = _normalize(query)
    results = []

    for product in queryset:
        tags = product.tags if isinstance(product.tags, list) else []
        cat_match = _category_matches(product.category, query)
        tag_sc = _tag_score(tags, query)
        txt_sc = _text_score(product.product_name, product.product_description, query)

        if cat_match:
            # Tier 1: 0.70–1.00 based on matching tags count
            base = 0.70
            score = base + tag_sc * 0.30
            reason = "Category match"
        elif tag_sc > 0:
            # Tier 2: 0.40–0.69
            base = 0.40
            score = base + tag_sc * 0.29
            reason = f"Tag match ({query})"
        elif txt_sc > 0:
            # Tier 3: 0.10–0.39
            base = 0.10
            score = base + txt_sc * 0.29
            reason = "Name/description match"
        else:
            continue  # Not relevant at all

        results.append((product, round(score, 4), reason))

    results.sort(key=lambda x: x[1], reverse=True)
    return results
