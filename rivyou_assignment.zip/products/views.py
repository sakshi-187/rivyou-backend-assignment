from rest_framework import status
from rest_framework.permissions import IsAuthenticated, IsAdminUser
from rest_framework.response import Response
from rest_framework.views import APIView
from drf_spectacular.utils import extend_schema, OpenApiParameter

from .models import Product
from .serializers import ProductSerializer, ProductCreateSerializer, SearchResultSerializer
from .search import rank_products


class ProductSearchView(APIView):
    permission_classes = [IsAuthenticated]

    @extend_schema(
        parameters=[
            OpenApiParameter('q', str, required=True, description='Search query'),
            OpenApiParameter('limit', int, required=False, description='Max results (default 20)'),
            OpenApiParameter('category_filter', str, required=False, description='Filter by category'),
            OpenApiParameter('page', int, required=False, description='Page number (default 1)'),
        ],
        responses={200: dict},
    )
    def get(self, request):
        query = request.query_params.get('q', '').strip()
        if not query:
            return Response({'error': 'Query parameter "q" is required.'}, status=status.HTTP_400_BAD_REQUEST)

        try:
            limit = int(request.query_params.get('limit', 20))
            limit = max(1, min(limit, 100))
        except ValueError:
            return Response({'error': '"limit" must be an integer.'}, status=status.HTTP_400_BAD_REQUEST)

        try:
            page = int(request.query_params.get('page', 1))
            page = max(1, page)
        except ValueError:
            return Response({'error': '"page" must be an integer.'}, status=status.HTTP_400_BAD_REQUEST)

        category_filter = request.query_params.get('category_filter', '').strip()
        queryset = Product.objects.all()
        if category_filter:
            queryset = queryset.filter(category__iexact=category_filter)

        ranked = rank_products(query, queryset)

        total = len(ranked)
        start = (page - 1) * limit
        end = start + limit
        page_results = ranked[start:end]

        results = []
        for product, score, reason in page_results:
            data = ProductSerializer(product).data
            data['relevance_score'] = score
            data['rank_reason'] = reason
            results.append(data)

        return Response({
            'query': query,
            'total_results': total,
            'page': page,
            'limit': limit,
            'results': results,
        })


class ProductDetailView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request, pk):
        try:
            product = Product.objects.get(pk=pk)
        except Product.DoesNotExist:
            return Response({'error': 'Product not found.'}, status=status.HTTP_404_NOT_FOUND)
        return Response(ProductSerializer(product).data)


class ProductCategoryView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request, category):
        products = Product.objects.filter(category__iexact=category)
        if not products.exists():
            return Response({'error': f'No products found in category "{category}".'}, status=status.HTTP_404_NOT_FOUND)
        return Response({
            'category': category,
            'count': products.count(),
            'results': ProductSerializer(products, many=True).data,
        })


class ProductCreateView(APIView):
    permission_classes = [IsAdminUser]

    def post(self, request):
        serializer = ProductCreateSerializer(data=request.data)
        if not serializer.is_valid():
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        product = serializer.save()
        return Response(ProductSerializer(product).data, status=status.HTTP_201_CREATED)
