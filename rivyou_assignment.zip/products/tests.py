"""
Unit tests for the search ranking logic.
Tests cover: tier ordering, score ranges, edge cases, case-insensitivity, partial matching.
"""
from django.test import TestCase
from .models import Product
from .search import rank_products, _category_matches, _tag_score, _text_score


def make_product(**kwargs):
    """Helper to create a Product in memory (not saved)."""
    defaults = {
        'id': 1,
        'product_name': 'Test Product',
        'product_description': 'A test product',
        'category': 'Smartphones',
        'tags': [],
    }
    defaults.update(kwargs)
    p = Product(**defaults)
    return p


class CategoryMatchTests(TestCase):
    def test_direct_match(self):
        self.assertTrue(_category_matches('Smartphones', 'smartphones'))

    def test_singular_alias(self):
        self.assertTrue(_category_matches('Smartphones', 'smartphone'))

    def test_phone_alias(self):
        self.assertTrue(_category_matches('Smartphones', 'phone'))

    def test_charger_alias(self):
        self.assertTrue(_category_matches('Chargers', 'charger'))

    def test_cover_alias(self):
        self.assertTrue(_category_matches('Back Covers', 'cover'))

    def test_no_match(self):
        self.assertFalse(_category_matches('Chargers', 'smartphone'))


class TagScoreTests(TestCase):
    def test_exact_match_single_tag(self):
        score = _tag_score(['smartphone'], 'smartphone')
        self.assertEqual(score, 1.0)

    def test_partial_match(self):
        score = _tag_score(['smartphone', 'camera', '5g'], 'phone')
        self.assertGreater(score, 0)

    def test_no_match(self):
        score = _tag_score(['camera', '5g'], 'smartphone')
        self.assertEqual(score, 0.0)

    def test_empty_tags(self):
        score = _tag_score([], 'smartphone')
        self.assertEqual(score, 0.0)


class TextScoreTests(TestCase):
    def test_name_match(self):
        score = _text_score('iPhone 15 Pro', 'A flagship', 'pro')
        self.assertGreater(score, 0)

    def test_description_match(self):
        score = _text_score('USB Charger', 'Compatible with smartphone devices', 'smartphone')
        self.assertGreater(score, 0)

    def test_no_match(self):
        score = _text_score('USB Charger', 'Fast charging', 'laptop')
        self.assertEqual(score, 0.0)


class RankingIntegrationTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        # Tier 1: actual smartphone
        Product.objects.create(
            product_name='iPhone 15 Pro',
            product_description='A flagship smartphone',
            category='Smartphones',
            tags=['5g', 'camera'],
        )
        # Tier 2: charger tagged with "smartphone"
        Product.objects.create(
            product_name='USB-C Fast Charger',
            product_description='Fast and reliable charging',
            category='Chargers',
            tags=['fast-charging', 'smartphone'],
        )
        # Tier 3: back cover with "smartphone" only in description
        Product.objects.create(
            product_name='Slim Case',
            product_description='Compatible with smartphone models',
            category='Back Covers',
            tags=['protective'],
        )
        # Irrelevant product
        Product.objects.create(
            product_name='Random Cable',
            product_description='A plain USB cable',
            category='Chargers',
            tags=['cable'],
        )

    def test_smartphones_ranked_first(self):
        results = rank_products('smartphone')
        self.assertGreater(len(results), 0)
        top_product, top_score, top_reason = results[0]
        self.assertEqual(top_product.category, 'Smartphones')
        self.assertIn('Category', top_reason)

    def test_tier1_score_range(self):
        results = rank_products('smartphone')
        tier1 = [(p, s, r) for p, s, r in results if 'Category' in r]
        for _, score, _ in tier1:
            self.assertGreaterEqual(score, 0.70)
            self.assertLessEqual(score, 1.0)

    def test_tier2_score_range(self):
        results = rank_products('smartphone')
        tier2 = [(p, s, r) for p, s, r in results if 'Tag match' in r]
        for _, score, _ in tier2:
            self.assertGreaterEqual(score, 0.40)
            self.assertLess(score, 0.70)

    def test_tier3_score_range(self):
        results = rank_products('smartphone')
        tier3 = [(p, s, r) for p, s, r in results if 'description' in r.lower()]
        for _, score, _ in tier3:
            self.assertGreaterEqual(score, 0.10)
            self.assertLess(score, 0.40)

    def test_irrelevant_excluded(self):
        results = rank_products('smartphone')
        names = [p.product_name for p, _, _ in results]
        self.assertNotIn('Random Cable', names)

    def test_tier_order(self):
        results = rank_products('smartphone')
        scores = [s for _, s, _ in results]
        self.assertEqual(scores, sorted(scores, reverse=True))

    def test_case_insensitive(self):
        lower = rank_products('smartphone')
        upper = rank_products('SMARTPHONE')
        self.assertEqual(len(lower), len(upper))

    def test_empty_query_fallback(self):
        # Should return no results for a query that matches nothing
        results = rank_products('xyznotexist')
        self.assertEqual(results, [])

    def test_partial_match(self):
        # "phone" should match Smartphones category
        results = rank_products('phone')
        tier1 = [p for p, _, r in results if 'Category' in r]
        self.assertGreater(len(tier1), 0)
        self.assertTrue(all(p.category == 'Smartphones' for p in tier1))
