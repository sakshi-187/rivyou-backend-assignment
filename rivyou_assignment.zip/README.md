# Rivyou Product Search API

A Django REST Framework backend with JWT authentication and a three-tier relevance ranking search engine.

---

## Quick Start

```bash
# 1. Install dependencies
pip install -r requirements.txt

# 2. Run migrations
python manage.py migrate

# 3. Load product data
python manage.py load_products --csv products_data.csv

# 4. (Optional) Create superuser for admin access
python manage.py createsuperuser

# 5. Run the server
python manage.py runserver
```

API docs will be available at **http://localhost:8000/api/docs/**

---

## API Endpoints

### Authentication

| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| POST | `/api/auth/register` | No | Register a new user |
| POST | `/api/auth/login` | No | Login, returns JWT |
| POST | `/api/auth/logout` | Yes | Invalidate refresh token |

**Register:**
```json
POST /api/auth/register
{"username": "alice", "email": "alice@example.com", "password": "secret123"}
→ {"id": 1, "username": "alice", "token": "<jwt>"}
```

**Login:**
```json
POST /api/auth/login
{"username": "alice", "password": "secret123"}
→ {"token": "<access_jwt>", "refresh": "<refresh_jwt>", "user": {"id": 1, "username": "alice"}}
```

**All protected endpoints** require:
```
Authorization: Bearer <token>
```

---

### Products

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/products/search?q=<query>` | Search with relevance ranking |
| GET | `/api/products/<id>` | Get a product by ID |
| GET | `/api/products/category/<category>` | List all products in a category |
| POST | `/api/products/` | Create a product (admin only) |

**Search parameters:**
- `q` (required) — search term
- `limit` (optional, default 20, max 100) — results per page
- `page` (optional, default 1) — pagination
- `category_filter` (optional) — e.g. `Smartphones`

**Search response:**
```json
{
  "query": "smartphone",
  "total_results": 430,
  "page": 1,
  "limit": 20,
  "results": [
    {
      "id": 1,
      "product_name": "Pixel 8 Pro Variant 0",
      "category": "Smartphones",
      "tags": ["camera", "5g", "fast-charging"],
      "relevance_score": 0.94,
      "rank_reason": "Category match"
    },
    {
      "id": 450,
      "product_name": "USB-C Charger Model 1",
      "category": "Chargers",
      "tags": ["fast-charging", "portable", "smartphone"],
      "relevance_score": 0.55,
      "rank_reason": "Tag match (smartphone)"
    }
  ]
}
```

---

## Relevance Ranking

The search engine uses a **three-tier scoring system (0.0 – 1.0)**:

| Tier | Score Range | Condition | Example |
|------|------------|-----------|---------|
| 1 | 0.70 – 1.00 | Product **category** matches query | Query "smartphone" → `category = Smartphones` |
| 2 | 0.40 – 0.69 | Product **tag** contains query (category doesn't match) | Charger tagged "smartphone" |
| 3 | 0.10 – 0.39 | Query in **product_name** or **description** | "Pro" in "iPhone 15 Pro" |

Within each tier, sub-ranking is done by match quality (more/exact tag matches score higher).

---

## Running Tests

```bash
python manage.py test products --verbosity=2
```

22 tests covering:
- Category alias matching (phone→Smartphones, charger→Chargers, cover→Back Covers)
- Tag exact vs partial scoring
- Text/description scoring
- Tier ordering guarantee (Tier 1 always before Tier 2 before Tier 3)
- Score range validation per tier
- Case-insensitive and partial matching
- Edge cases (empty tags, no results)

---

## Database Setup (PostgreSQL)

For production, update `DATABASES` in `settings.py`:
```python
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.postgresql',
        'NAME': 'rivyou_db',
        'USER': 'rivyou_user',
        'PASSWORD': 'your_password',
        'HOST': 'localhost',
        'PORT': '5432',
    }
}
```

Then run migrations and load data:
```bash
python manage.py migrate
python manage.py load_products --csv products_data.csv --clear
```

The `--clear` flag drops existing products before re-loading.

---

## Project Structure

```
rivyou/                  ← Django project config
├── settings.py
├── urls.py
users/                   ← Auth app
├── models.py            (custom User model)
├── serializers.py
├── views.py             (register, login, logout)
├── urls.py
products/                ← Products app
├── models.py            (Product model)
├── serializers.py
├── views.py             (search, detail, category, create)
├── urls.py
├── search.py            ← ⭐ Three-tier ranking engine
├── tests.py             (22 unit tests)
└── management/
    └── commands/
        └── load_products.py   ← CSV import command
```
